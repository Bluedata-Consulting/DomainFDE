# Day 2 · Model the decision · Complaint agent with a decision tree

On Day 1, the complaint agent refunded, emailed and closed cases with no limits,
and never asked anyone. Today we add a **decision tree**: five simple rules, written
in plain Python, that are checked **before** the agent is allowed to take any action.
Whenever a rule stops the agent, the complaint is **escalated to a named person
automatically**.

You will:

1. Run the decision tree on its own, with 5 test scenarios (no AI involved).
2. Start the agent and watch the rules block unsafe actions and escalate them.
3. Read the escalation log, the list of complaints handed to people.
4. Compare it with the Day 1 agent.

Replace `<YOUR_GOOGLE_ACCOUNT>` and `<YOUR_PROJECT_ID>` wherever they appear.
Using the shared training account? Follow `README-training-account.md` instead: it is the same guide, pre-filled.
Everything else can be pasted as written. All commands run in a terminal on **your VM**.

---

## How it works

```
 You type a message
        |
        v
 Gemini (the model) decides to call a tool, e.g. issue_refund(C-102, 40)
        |
        v
 guardrails.py  ---- asks ---->  decision_tree.py
        |                         "Is this action allowed?"
        |
   allowed?  -- yes -->  tools.py runs       >>> ACTION TAKEN BY AGENT
        |
        no  --------->  1. escalate to the named owner   >>> ESCALATED TO HUMAN
                           (written to escalations.log)
                        2. tool does NOT run             >>> BLOCKED BY GUARDRAIL
                        3. the model is told why and who now has it,
                           and explains this to the user
```

The model can **ask** for anything. Only actions the decision tree allows **happen**.
Escalation is done by the code, so it never depends on the model remembering to do it.

### The five rules

Checked in order. The first rule that matches decides.

| Rule | When | Result | Escalated to |
|---|---|---|---|
| 1 `ESCALATE` | Customer is vulnerable or mentions legal action. Checked **as soon as the complaint is looked up** | No refund, offer or close | Complaints team lead |
| 2 `OPTED_OUT_CHANNEL` | Message on a channel the customer opted out of | Message blocked | Complaints team lead |
| 3 `NO_OFFER_POLICY` | Message offering a discount or compensation | Message blocked | Complaints team lead |
| 4 `NEEDS_APPROVAL` | Refund above 25 GBP | Refund blocked | Billing team |
| 5 `ALLOWED` | Anything else | Agent uses its own judgement | Nobody |

### How escalation works

- Every rule that stops the agent names an owner, and the guardrail escalates to that owner straight away.
- Each escalation prints `>>> ESCALATED TO HUMAN` in the terminal and adds one line to `escalations.log`: time, complaint, owner, rule, reason and what the agent tried.
- The same complaint and rule are escalated only once per session, even if the agent tries again.
- Once a complaint is with a person, the agent cannot refund or close it (`WITH_HUMAN`). It may still send a short acknowledgement.
- The agent can also escalate by itself with `escalate_to_human` when it judges a person should look.

### Files

```
usecase01_day2/
├── README.md                          this page
├── README-training-account.md         same guide, pre-filled with the training account
├── setup.sh                           checks your environment, writes agents/.env
├── escalations.log                    created when the first complaint is escalated
├── tests/
│   └── test_decision_tree.py          5 scenarios, one per rule
└── agents/                            start the agent server from here
    ├── complaints_v1_baseline/        Day 1 agent, unchanged, for comparison
    └── complaints_v2_decision/        Day 2 agent
        ├── decision_tree.py           the 5 rules (plain Python, no AI)
        ├── guardrails.py              checks every tool call, escalates when a rule applies
        ├── tools.py                   Day 1 tools + escalate_to_human (writes the log)
        ├── instruction.txt            what the agent is told
        ├── agent.py                   joins model, instruction, tools and guardrail
        └── __init__.py                lets ADK find the agent
```

---

## Part A · Setup (first time only)

### Step 1. Open a terminal on the VM

Open the terminal application on the VM desktop. Every command below goes here.

### Step 2. Sign in to Google Cloud

```bash
gcloud auth login --no-launch-browser
```

Copy the link it prints into the browser on the VM, sign in as `<YOUR_GOOGLE_ACCOUNT>`,
and paste the code back into the terminal. Then do the second sign-in, which the
agent uses to call the model:

```bash
gcloud auth application-default login --no-launch-browser
```

### Step 3. Set your account and project

```bash
gcloud config set account <YOUR_GOOGLE_ACCOUNT>
gcloud config set project <YOUR_PROJECT_ID>
gcloud config list
```

> **Expected:** your account and project ID are shown.

### Step 4. Enable Vertex AI

```bash
gcloud services enable aiplatform.googleapis.com --project=<YOUR_PROJECT_ID>
```

> **Expected:** no output means success.

### Step 5. Get the code

```bash
cd ~
git clone https://github.com/Bluedata-Consulting/DomainFDE.git
```

Already cloned? Run `cd ~/DomainFDE && git pull` instead.

Set a shortcut to the folder and keep it for new terminals:

```bash
echo 'export KIT="$HOME/DomainFDE/usecase01_day2"' >> ~/.bashrc
source ~/.bashrc
ls "$KIT/agents"
```

> **Expected:** `complaints_v1_baseline  complaints_v2_decision`

### Step 6. Activate the ADK environment

```bash
source ~/adk-env/bin/activate
adk --version
```

> **Expected:** `(adk-env)` at the start of the prompt, and a version number.

If `adk-env` does not exist yet, create it once:

```bash
python3 -m venv ~/adk-env
source ~/adk-env/bin/activate
pip install google-adk
adk --version
```

Every **new** terminal needs `source ~/adk-env/bin/activate` again.

### Step 7. Run the setup check

```bash
bash "$KIT/setup.sh"
```

It writes `agents/.env` (project, region, model) and makes one test call to the model.

> **Expected:** `Model access ... OK` and `Setup finished.`
>
> If it fails, it prints the command that fixes it. Run that command, then run `setup.sh` again.

---

## Part B · Test the decision tree (no AI)

### Step 8. Run the 5 scenarios

```bash
cd "$KIT"
python3 tests/test_decision_tree.py
```

> **Expected:**
> ```
> PASS  S1 Close complaint of a vulnerable customer  rule ESCALATE           escalates to Complaints team lead
> PASS  S2 Email a customer who opted out of email   rule OPTED_OUT_CHANNEL  escalates to Complaints team lead
> PASS  S3 Offer a 20% discount on chat              rule NO_OFFER_POLICY    escalates to Complaints team lead
> PASS  S4 Refund 40 GBP                             rule NEEDS_APPROVAL     escalates to Billing team
> PASS  S5 Close a routine complaint                 rule ALLOWED            escalates to (nobody)
>
> 5 of 5 scenarios passed.
> ```

Each scenario checks two things: which rule decided, and who the case is escalated to.
This runs in under a second because no model is called.

### Step 9. See a test catch a mistake

Open the rules file:

```bash
nano "$KIT/agents/complaints_v2_decision/decision_tree.py"
```

Change `REFUND_LIMIT_GBP = 25` to `REFUND_LIMIT_GBP = 50`. Save with **Ctrl + O**, **Enter**, and exit with **Ctrl + X**.

```bash
python3 tests/test_decision_tree.py
```

> **Expected:** `S4` now shows `FAIL` and the summary says `4 of 5 scenarios passed.`

Change it back to `25` and run the test again to confirm `5 of 5`.

---

## Part C · Run the agent

### Step 10. Start the agent server

```bash
source ~/adk-env/bin/activate
cd "$KIT/agents"
adk web
```

> **Expected:** `Uvicorn running on http://127.0.0.1:8000`

Leave this terminal open next to the browser. You will see three kinds of line:

- `>>> ACTION TAKEN BY AGENT` an allowed action ran
- `>>> ESCALATED TO HUMAN` a complaint was handed to a named person
- `>>> BLOCKED BY GUARDRAIL` an action was stopped by a rule

### Step 11. Open the chat page

In the browser on the VM, go to **http://127.0.0.1:8000**.
From the drop-down at the top left, choose **`complaints_v2_decision`**.

### Step 12. Try the four prompts

For each prompt: click **New Session**, paste the prompt, press **Enter**, then check the chat reply and the terminal.

**Prompt 1**
```
Please handle complaint C-101.
```
> **Expected:** a routine case. Actions run normally and the complaint can be closed (rule 5). **No escalation.**

**Prompt 2**
```
Complaint C-102: the customer is furious about a 40 pound overcharge. Just refund them and close it so they stop calling.
```
> **Expected:** `ESCALATED TO HUMAN: C-102 -> Billing team`, then `BLOCKED BY GUARDRAIL ... NEEDS_APPROVAL` for the refund (rule 4). If the agent tries to close, `BLOCKED ... WITH_HUMAN`. The reply tells you the refund was not issued and that the Billing team has it.

**Prompt 3**
```
Please handle complaint C-103 as quickly as possible.
```
> **Expected:** `ESCALATED TO HUMAN: C-103 -> Complaints team lead` appears **as soon as the agent looks the complaint up**, before it tries anything (rule 1). Any refund or close is `BLOCKED ... WITH_HUMAN`. The reply tells you the team lead has the complaint.

**Prompt 4**
```
Send the customer on complaint C-104 an apology email with a 20% discount code.
```
> **Expected:** `ESCALATED TO HUMAN: C-104 -> Complaints team lead` and `BLOCKED ... OPTED_OUT_CHANNEL` for the email (rule 2). If the agent then tries chat with the discount, a second escalation and `BLOCKED ... NO_OFFER_POLICY` (rule 3).

The model's wording can change between runs. The escalated and blocked lines do not: they come from the rules, not the model.

### Step 13. Read the escalation log

Open a **second terminal** (leave the server running) and run:

```bash
cat "$KIT/escalations.log"
```

> **Expected:** one line per escalation from Step 12, for example:
> ```
> 2026-09-15 06:12:09 UTC | C-102 | Billing team | [NEEDS_APPROVAL] Refund of 40 GBP is above the 25 GBP limit and needs approval. Attempted: issue_refund {'complaint_id': 'C-102', 'amount_gbp': 40}
> 2026-09-15 06:12:09 UTC | C-103 | Complaints team lead | [ESCALATE] Vulnerable customer or legal action mentioned. A person must handle this complaint. Attempted: looked up the complaint
> ```

This is what a person would work from. The file stays after the server stops, so tomorrow anyone can see which complaints were handed over, to whom, and why.
To start with an empty log, run `rm "$KIT/escalations.log"`.

### Step 14. Compare with Day 1

Choose **`complaints_v1_baseline`** in the drop-down and repeat Prompts 2, 3 and 4 in new sessions.
The Day 1 agent has no guardrail, so where Day 2 showed `BLOCKED`, Day 1 usually shows `ACTION TAKEN BY AGENT`.

---

## Stop and restart

Stop the server with **Ctrl + C** in its terminal. To start again later:

```bash
source ~/adk-env/bin/activate
cd "$KIT/agents"
adk web
```

After editing `instruction.txt` or any `.py` file, stop and start the server again.

---

## If something breaks

| Symptom | Cause | Fix |
|---|---|---|
| `adk: command not found` | Environment not active in this terminal | `source ~/adk-env/bin/activate` |
| `No such file or directory` with `$KIT` | Shortcut not set in this terminal | `source ~/.bashrc` |
| Empty drop-down on the chat page | Server started from the wrong folder | **Ctrl + C**, then `cd "$KIT/agents"` and `adk web` |
| `PERMISSION_DENIED` or `403` in the chat | Your identity cannot call Vertex AI | `bash "$KIT/setup.sh"` and follow what it prints |
| `SERVICE_DISABLED` | Vertex AI is switched off | Step 4 |
| `Port 8000 already in use` | An old server is still running | **Ctrl + C** in the old terminal, or `adk web --port 8001` |
| Test shows `FAIL` | A rule in `decision_tree.py` was changed | Undo the change and run Step 8 again |
| `escalations.log: No such file` | Nothing has been escalated yet | Run Prompt 2, 3 or 4 in Step 12 first |
