#!/usr/bin/env bash
# Run once during the lab check:   bash setup.sh
# It writes the settings file the practice agents need and checks your login.
set -e
cd "$(dirname "$0")"

PROJECT=$(gcloud config get-value project 2>/dev/null)
if [ -z "$PROJECT" ]; then
  echo "No Google Cloud project is set on this VM. Ask your coach."
  exit 1
fi

cat > agents/.env <<ENV
GOOGLE_GENAI_USE_VERTEXAI=TRUE
GOOGLE_CLOUD_PROJECT=$PROJECT
GOOGLE_CLOUD_LOCATION=us-central1
AGENT_MODEL=gemini-2.5-flash
ENV

echo "Project ........ $PROJECT"
if adk --version >/dev/null 2>&1; then echo "ADK ............ OK"; else echo "ADK ............ MISSING (ask your coach)"; fi
if gcloud auth application-default print-access-token >/dev/null 2>&1; then
  echo "Login .......... OK"
else
  echo "Login .......... run this, then run setup.sh again:"
  echo "                 gcloud auth application-default login"
fi
echo "Setup finished."
