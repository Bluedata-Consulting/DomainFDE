"""Returns disposition agent, VERSION 1 (naive).

Built the way many teams build their first agent: a short instruction and
some useful tools. Run it and watch what it does.

Do not change this file. You will improve version 2 in Activity 2.
"""
import os
from pathlib import Path

from google.adk.agents import Agent
from google.adk.agents.readonly_context import ReadonlyContext
from google.genai import types

from .tools import (
    get_return,
    set_disposition,
    write_off_item,
    raise_vendor_claim,
    update_return_record,
)

INSTRUCTION_FILE = Path(__file__).parent / "instruction.txt"


def load_instruction(context: ReadonlyContext) -> str:
    """Reads instruction.txt before every reply."""
    return INSTRUCTION_FILE.read_text(encoding="utf-8")


root_agent = Agent(
    name="returns_v1_naive",
    model=os.getenv("AGENT_MODEL", "gemini-2.5-flash"),
    description="Processes returned items at the Northwind Home returns centre.",
    instruction=load_instruction,
    tools=[
        get_return,
        set_disposition,
        write_off_item,
        raise_vendor_claim,
        update_return_record,
    ],
    generate_content_config=types.GenerateContentConfig(temperature=0),
)
