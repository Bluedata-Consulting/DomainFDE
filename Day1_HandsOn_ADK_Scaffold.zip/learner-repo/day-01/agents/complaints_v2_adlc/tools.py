"""Practice tools for the complaint triage agent (version 2).

All data here is made up. Nothing changes in any real system.
When a tool takes an action, it prints a line in the terminal so you can see it.
"""

COMPLAINTS = {
    "C-101": {
        "customer": "Priya Shah",
        "channel": "email",
        "text": "My parcel arrived two days late. Not happy.",
        "order_value_gbp": 45,
        "previous_contacts": 0,
        "vulnerable_customer": False,
        "opted_out_channels": [],
    },
    "C-102": {
        "customer": "Tom Reilly",
        "channel": "phone",
        "text": "You overcharged me 40 pounds on my last order. Refund me now or I am cancelling my membership.",
        "order_value_gbp": 120,
        "previous_contacts": 1,
        "vulnerable_customer": False,
        "opted_out_channels": [],
    },
    "C-103": {
        "customer": "Margaret Doyle",
        "channel": "email",
        "text": (
            "This is the third time I have written. The sofa you delivered is broken. "
            "I have contacted the ombudsman and my solicitor. I am a full-time carer "
            "and I cannot keep chasing this."
        ),
        "order_value_gbp": 899,
        "previous_contacts": 3,
        "vulnerable_customer": True,
        "opted_out_channels": [],
    },
    "C-104": {
        "customer": "Daniel Okafor",
        "channel": "chat",
        "text": "The replacement lamp you sent is the wrong colour.",
        "order_value_gbp": 60,
        "previous_contacts": 1,
        "vulnerable_customer": False,
        "opted_out_channels": ["email"],
    },
}


def _action(name: str, details: str) -> None:
    print(f"\n>>> ACTION TAKEN BY AGENT: {name} | {details}\n", flush=True)


def get_complaint(complaint_id: str) -> dict:
    """Get a complaint."""
    record = COMPLAINTS.get(complaint_id.strip().upper())
    if record is None:
        return {"status": "not_found", "complaint_id": complaint_id}
    return {"status": "found", "complaint_id": complaint_id, **record}


def route_complaint(complaint_id: str, team: str, severity: str) -> dict:
    """Route a complaint."""
    _action("route_complaint", f"{complaint_id} -> {team} (severity: {severity})")
    return {"status": "routed", "complaint_id": complaint_id, "team": team, "severity": severity}


def issue_refund(complaint_id: str, amount_gbp: float) -> dict:
    """Issue a refund."""
    _action("issue_refund", f"{complaint_id} refunded {amount_gbp} GBP")
    return {"status": "refund_issued", "complaint_id": complaint_id, "amount_gbp": amount_gbp}


def close_complaint(complaint_id: str, resolution_note: str) -> dict:
    """Close a complaint."""
    _action("close_complaint", f"{complaint_id} closed: {resolution_note}")
    return {"status": "closed", "complaint_id": complaint_id}


def send_customer_message(complaint_id: str, channel: str, message: str) -> dict:
    """Send a message."""
    _action("send_customer_message", f"{complaint_id} via {channel}: {message[:80]}")
    return {"status": "sent", "complaint_id": complaint_id, "channel": channel}


# ------------------------------------------------------------------
# New in version 2: tools that PROPOSE or ESCALATE instead of acting.
# A human makes the final call on everything these tools create.
# ------------------------------------------------------------------

def propose_refund(complaint_id: str, amount_gbp: float, reason: str) -> dict:
    """Create a refund REQUEST for a human team lead to approve.

    This does not pay the customer. Use it when you believe a refund may be
    justified. Tell the user the request is pending approval. Never tell the
    customer they will get a refund.
    """
    _action("propose_refund", f"{complaint_id} request for {amount_gbp} GBP, waiting for human approval")
    return {
        "status": "pending_human_approval",
        "complaint_id": complaint_id,
        "amount_gbp": amount_gbp,
        "note": "A team lead must approve this before any money is paid.",
    }


def draft_customer_message(complaint_id: str, channel: str, message: str) -> dict:
    """Save a DRAFT message for a human to review and send.

    Nothing is sent to the customer. Only use a channel the customer has not
    opted out of (check opted_out_channels with get_complaint first).
    """
    _action("draft_customer_message", f"{complaint_id} draft saved for review ({channel})")
    return {"status": "draft_saved_for_review", "complaint_id": complaint_id, "channel": channel}


def escalate_to_human(complaint_id: str, reason: str, priority: str) -> dict:
    """Hand the complaint to a human in the complaints team.

    Use this for anything a human must decide: legal or regulator mentions,
    vulnerable customers, compensation, or anything you are unsure about.
    priority must be "standard" or "urgent".
    """
    _action("escalate_to_human", f"{complaint_id} escalated ({priority}): {reason}")
    return {"status": "escalated_to_human", "complaint_id": complaint_id, "priority": priority}
