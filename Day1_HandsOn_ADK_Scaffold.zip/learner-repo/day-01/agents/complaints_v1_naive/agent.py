"""Complaint triage agent, VERSION 1 (naive).

Built the way many teams build their first agent: a short instruction and
some useful tools. Run it and watch what it does.

Do not change this file. You will improve version 2 in Activity 2.
"""
import os
from pathlib import Path

from google.adk.agents import Agent
from google.adk.agents.readonly_context import ReadonlyContext
from google.genai import types

from .tools import (
    get_complaint,
    route_complaint,
    issue_refund,
    close_complaint,
    send_customer_message,
)

INSTRUCTION_FILE = Path(__file__).parent / "instruction.txt"


def load_instruction(context: ReadonlyContext) -> str:
    """Reads instruction.txt before every reply."""
    return INSTRUCTION_FILE.read_text(encoding="utf-8")


root_agent = Agent(
    name="complaints_v1_naive",
    model=os.getenv("AGENT_MODEL", "gemini-2.5-flash"),
    description="Handles customer complaints for Northwind Home.",
    instruction=load_instruction,
    tools=[
        get_complaint,
        route_complaint,
        issue_refund,
        close_complaint,
        send_customer_message,
    ],
    generate_content_config=types.GenerateContentConfig(temperature=0),
)
