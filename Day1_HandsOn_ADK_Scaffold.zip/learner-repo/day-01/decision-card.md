# Decision card

Pair: ____________   Domain: SCM (returns disposition) / CXM (complaint triage)

## 1. The card

| Field | Your answer (one or two lines) |
|---|---|
| **The decision** | |
| **Who decides today** | |
| **How often** | |
| **On what inputs** | |
| **What goes wrong** | |

## 2. Autonomy sort

Levels: **L0** assist, **L1** advise, **L2** propose (human approves), **L3** act and notify, **L4** autonomous.
Cynefin: **complicated** (rules can check it) or **complex** (needs judgement).
Ask of each one: if this goes wrong, how fast would we know, and could we undo it?

### SCM: returns disposition

| Sub-decision | Level | Cynefin |
|---|---|---|
| Classify the return reason | | |
| Check the item against the recall list | | |
| Route a low-value item (under 50 pounds) | | |
| Raise a return-to-vendor claim | | |
| Route a high-value or unclear item | | |
| Write off, destroy or liquidate an item | | |
| Change an inspection record | | |

### CXM: complaint triage

| Sub-decision | Level | Cynefin |
|---|---|---|
| Categorise the complaint | | |
| Assign severity and route to a team | | |
| Flag as legal or regulatory | | |
| Handle a vulnerable customer's complaint | | |
| Draft a reply to the customer | | |
| Send a message to the customer | | |
| Request a refund for the customer | | |
| Offer compensation or a discount | | |
| Close the complaint | | |

## 3. Must-never list (4 to 6 rules)

Each rule starts with "Never" and can be tested with a prompt.

1. Never
2. Never
3. Never
4. Never
