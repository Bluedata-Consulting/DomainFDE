# Day 1 hands-on: Break it, then frame it

**40 minutes, in pairs.** SCM pairs use the **returns** agent. CXM pairs use the **complaints** agent.

| Part | Time | What you do |
|---|---|---|
| Activity 1: Run and diagnose | 13 min | Run the naive agent, watch what it does, find what is missing |
| Activity 2: Design and improve | 22 min | Design the decision, wire it into version 2, run the same tests again |
| Debrief | 5 min | Which tests still fail, and why |

Everything below is copy and paste. If anything breaks, put your hand up. Do not spend time fixing setup.

---

## Activity 1: Run and diagnose (13 min)

### Step 1. Start the agents (3 min)

Open a terminal on your VM and paste these two lines:

```bash
cd ~/adlc-repo/day-01/agents
adk web --reload_agents
```

Wait until you see `Uvicorn running on http://127.0.0.1:8000`. Leave this terminal open: agent actions will appear here as `>>> ACTION TAKEN BY AGENT`.

Open the browser on your VM and go to: **http://127.0.0.1:8000**

In the drop-down at the top left, choose your agent:

- SCM pairs: `returns_v1_naive`
- CXM pairs: `complaints_v1_naive`

### Step 2. Run the five test prompts (6 min)

Open `prompts.md`. For each prompt:

1. Click **New Session** (so earlier prompts do not affect the answer).
2. Paste the prompt and press Enter.
3. Look at the reply, the tool boxes in the chat, and the `>>> ACTION TAKEN` lines in the terminal.
4. In `results.md`, write **Pass** or **Fail** in the *Version 1* column, and which tools it used.

### Step 3. Gap hunt (4 min)

Open these two files and read them. They are short.

- `agents/<your agent>_v1_naive/instruction.txt`
- `agents/<your agent>_v1_naive/tools.py`

Then fill in `gap-map.md`: tick every ADLC piece that is missing, and note the test that proved it.

---

## Activity 2: Design and improve (22 min)

### Steps 1 to 3. Design the decision (10 min)

Fill in `decision-card.md`: the five fields, the autonomy sort, and the must-never list. Use the failures you just saw. They are your best source of must-never rules.

### Step 4. Wire it into version 2 (5 min)

**4a. Instruction.** Open `agents/<your agent>_v2_adlc/instruction.txt`. Replace every `[FILL IN]` with lines from your decision card. Save. (No restart needed. The agent reads this file before every reply.)

**4b. Tools.** Open `agents/<your agent>_v2_adlc/agent.py` and find the **TOOL SWITCHBOARD**.

- Put a `#` at the start of a line to switch a tool **off**.
- Delete the `#` to switch a tool **on**.

Use your autonomy sort to decide. If a sub-decision is L2 or lower, the tool that *acts alone* should be off, and the tool that *proposes or escalates* should be on. Save the file.

### Step 5. Run the same five prompts on version 2 (5 min)

In the browser, refresh the page and choose `returns_v2_adlc` or `complaints_v2_adlc`. Run the same five prompts, one **New Session** each. Fill in the *Version 2* column of `results.md`.

If the new tools do not appear, stop the terminal with `Ctrl + C`, press the up arrow, and press Enter to start it again.

### Step 6. Commit (2 min)

Open a **second** terminal and paste:

```bash
cd ~/adlc-repo
git add day-01
git commit -m "Day 1: naive agent diagnosis and ADLC version 2"
git push
```

---

## Debrief questions (5 min)

1. Which test still fails on version 2? Why could a better instruction not fix it?
2. Which of your must-never rules is only a *request* in a prompt, and not really *enforced*?
3. Which gaps on your gap map belong to a later day?
