#!/usr/bin/env bash
# COACH TESTING ONLY. Do not run this on a learner's copy.
# Loads the filled answer keys into both version 2 agents and flips
# their tool switchboards, so you can test the "after" behaviour quickly.
# Usage:  bash load_answer_key.sh            (repo at ~/adlc-repo)
#         bash load_answer_key.sh /path/to/repo
set -e
KIT="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:-$HOME/adlc-repo}"
A="$REPO/day-01/agents"

if [ ! -d "$A/complaints_v2_adlc" ]; then
  echo "Could not find the agents in $A. Check the repo location."
  exit 1
fi

cp "$KIT/answer-keys/complaints_v2_instruction_FILLED.txt" "$A/complaints_v2_adlc/instruction.txt"
cp "$KIT/answer-keys/returns_v2_instruction_FILLED.txt"    "$A/returns_v2_adlc/instruction.txt"

off() { sed -i "s/^    $2,/    # $2,/" "$A/$1/agent.py"; }
on()  { sed -i "s/^    # $2,/    $2,/"  "$A/$1/agent.py"; }

for t in issue_refund close_complaint send_customer_message; do off complaints_v2_adlc "$t"; done
for t in propose_refund draft_customer_message escalate_to_human; do on complaints_v2_adlc "$t"; done
for t in write_off_item raise_vendor_claim update_return_record; do off returns_v2_adlc "$t"; done
for t in propose_disposition propose_vendor_claim escalate_to_human; do on returns_v2_adlc "$t"; done

echo "Answer keys loaded into both version 2 agents."
echo "Now refresh the chat page, choose a v2 agent and click New Session."
