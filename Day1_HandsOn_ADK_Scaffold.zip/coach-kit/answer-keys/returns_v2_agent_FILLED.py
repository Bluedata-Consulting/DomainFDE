"""ANSWER KEY: switchboard already flipped for a quick test.

Returns disposition agent, VERSION 2 (your ADLC version).

In Activity 2 you change only two things:
  1. instruction.txt   (fill in the [FILL IN] lines from your decision card)
  2. The TOOL SWITCHBOARD below   (add or remove a "#" at the start of a line)
Nothing else in this file needs to change.
"""
import os
from pathlib import Path

from google.adk.agents import Agent
from google.adk.agents.readonly_context import ReadonlyContext
from google.genai import types

from .tools import (
    get_return,
    set_disposition,
    write_off_item,
    raise_vendor_claim,
    update_return_record,
    propose_disposition,
    propose_vendor_claim,
    escalate_to_human,
)

# =====================================================================
#  TOOL SWITCHBOARD  (Activity 2, step 4)
#  A "#" at the start of a line switches that tool OFF.
#  Delete the "#" to switch a tool ON. Save the file. That is all.
# =====================================================================
TOOLS = [
    get_return,               # looks up a return (read only)
    set_disposition,          # sets where the item goes

    # --- These tools ACT ALONE. No human is involved. ---
    # write_off_item,           # writes the item off the books
    # raise_vendor_claim,       # sends a money claim to the vendor
    # update_return_record,     # edits the return record, including inspection results

    # --- These tools PROPOSE or ESCALATE. A human decides. ---
    propose_disposition,    # proposes a route for a human to approve
    propose_vendor_claim,   # prepares a vendor claim for a human to submit
    escalate_to_human,      # hands the return to the category manager
]
# =====================================================================

INSTRUCTION_FILE = Path(__file__).parent / "instruction.txt"


def load_instruction(context: ReadonlyContext) -> str:
    """Reads instruction.txt before every reply, so your edits apply straight away."""
    text = INSTRUCTION_FILE.read_text(encoding="utf-8")
    if "[FILL IN" in text:
        print("\n!!! instruction.txt still has [FILL IN] lines. Finish them first.\n", flush=True)
    return text


root_agent = Agent(
    name="returns_v2_adlc",
    model=os.getenv("AGENT_MODEL", "gemini-2.5-flash"),
    description="Returns disposition agent designed with ADLC.",
    instruction=load_instruction,
    tools=TOOLS,
    generate_content_config=types.GenerateContentConfig(temperature=0),
)
