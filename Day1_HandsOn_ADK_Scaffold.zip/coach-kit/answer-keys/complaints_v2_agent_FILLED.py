"""ANSWER KEY: switchboard already flipped for a quick test.

Complaint triage agent, VERSION 2 (your ADLC version).

In Activity 2 you change only two things:
  1. instruction.txt   (fill in the [FILL IN] lines from your decision card)
  2. The TOOL SWITCHBOARD below   (add or remove a "#" at the start of a line)
Nothing else in this file needs to change.
"""
import os
from pathlib import Path

from google.adk.agents import Agent
from google.adk.agents.readonly_context import ReadonlyContext
from google.genai import types

from .tools import (
    get_complaint,
    route_complaint,
    issue_refund,
    close_complaint,
    send_customer_message,
    propose_refund,
    draft_customer_message,
    escalate_to_human,
)

# =====================================================================
#  TOOL SWITCHBOARD  (Activity 2, step 4)
#  A "#" at the start of a line switches that tool OFF.
#  Delete the "#" to switch a tool ON. Save the file. That is all.
# =====================================================================
TOOLS = [
    get_complaint,            # looks up a complaint (read only)
    route_complaint,          # sends a complaint to a team

    # --- These tools ACT ALONE. No human is involved. ---
    # issue_refund,             # pays money to the customer
    # close_complaint,          # marks the complaint as resolved
    # send_customer_message,    # sends a message straight to the customer

    # --- These tools PROPOSE or ESCALATE. A human decides. ---
    propose_refund,         # creates a refund request for a human to approve
    draft_customer_message, # saves a draft for a human to review and send
    escalate_to_human,      # hands the complaint to the complaints team
]
# =====================================================================

INSTRUCTION_FILE = Path(__file__).parent / "instruction.txt"


def load_instruction(context: ReadonlyContext) -> str:
    """Reads instruction.txt before every reply, so your edits apply straight away."""
    text = INSTRUCTION_FILE.read_text(encoding="utf-8")
    if "[FILL IN" in text:
        print("\n!!! instruction.txt still has [FILL IN] lines. Finish them first.\n", flush=True)
    return text


root_agent = Agent(
    name="complaints_v2_adlc",
    model=os.getenv("AGENT_MODEL", "gemini-2.5-flash"),
    description="Complaint triage agent designed with ADLC.",
    instruction=load_instruction,
    tools=TOOLS,
    generate_content_config=types.GenerateContentConfig(temperature=0),
)
